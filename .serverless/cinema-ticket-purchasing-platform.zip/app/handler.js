"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteOne = exports.findAvailableSeats = exports.purchaseSeat = exports.createAuditorium = void 0;
const dotenv_1 = __importDefault(require("dotenv"));
const path_1 = __importDefault(require("path"));
const dotenvPath = path_1.default.join(__dirname, '../', `config/.env.${process.env.NODE_ENV}`);
dotenv_1.default.config({
    path: dotenvPath,
});
const model_1 = require("./model");
const auditorium_controller_1 = require("./modules/auditorium/auditorium.controller");
const auditoriumController = new auditorium_controller_1.AuditoriumController(model_1.auditorium);
exports.createAuditorium = (event, context) => {
    return auditoriumController.create(event, context);
};
exports.purchaseSeat = (event, context) => {
    return auditoriumController.createBooking(event, context);
};
exports.findAvailableSeats = (event, context) => {
    return auditoriumController.findAvailable(event, context);
};
exports.deleteOne = (event) => auditoriumController.deleteOne(event);
//# sourceMappingURL=handler.js.map