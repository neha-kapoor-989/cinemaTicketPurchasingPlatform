"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.auditorium = void 0;
const mongoose_1 = __importDefault(require("mongoose"));
const auditoriumSchema = new mongoose_1.default.Schema({
    id: {
        type: String,
        index: true,
        unique: true
    },
    name: String,
    totalSeats: Number,
    description: Number,
    createdAt: { type: Date, default: Date.now },
});
exports.auditorium = (mongoose_1.default.models.cinema ||
    mongoose_1.default.model('cinema', auditoriumSchema));
//# sourceMappingURL=auditorium.js.map