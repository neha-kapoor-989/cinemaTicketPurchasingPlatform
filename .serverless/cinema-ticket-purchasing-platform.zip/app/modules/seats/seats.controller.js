"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SeatsController = void 0;
const seats_service_1 = require("./seats.service");
const message_1 = require("../../utils/message");
class SeatsController extends seats_service_1.SeatsService {
    constructor(seats) {
        super(seats);
    }
    async createAuditoriumSeats(auditoriumId, id, totalSeats) {
        const rowCount = Math.round(totalSeats / 10);
        const rowName = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S'];
        for (let i = 0; i < rowCount; i++) {
            [...Array(10)].forEach((_, j) => {
                let createRow = { id: rowName[i] + j, row: rowName[i], auditoriumRefId: auditoriumId, auditoriumId: id };
                if (j == 0 || j === 9) {
                    createRow['corner'] = true;
                }
                this.createSeat(createRow);
            });
        }
    }
    /**
     * Find all available seats list
     */
    async findAvailableSeats(id) {
        try {
            const result = await this.findSeats(id);
            return result;
        }
        catch (err) {
            console.log(err);
            return [];
        }
    }
    /**
     * Update a book by id
     * @param event
     */
    async update(_id, bookingId) {
        try {
            const result = await this.updateSeat(_id, bookingId);
            return message_1.MessageUtil.success(result);
        }
        catch (err) {
            console.error('updateSeat', err);
            return message_1.MessageUtil.error(err.code, err.message);
        }
    }
    /**
     * Find for one seat
     */
    async checkSeatFree(auditoriumId, seatId) {
        try {
            const result = await this.checkSeatAvailable(auditoriumId, seatId);
            return result;
        }
        catch (err) {
            console.log(err);
            return [];
        }
    }
}
exports.SeatsController = SeatsController;
//# sourceMappingURL=seats.controller.js.map