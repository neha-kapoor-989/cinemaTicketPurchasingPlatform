"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SeatsService = void 0;
class SeatsService {
    constructor(seats) {
        this.seats = seats;
    }
    /**
     * Create seat for a auditorium
     * @param data
     */
    async createSeat(dataSet) {
        try {
            const result = await this.seats.create(dataSet);
            return result;
        }
        catch (err) {
            console.error('createSeats', err);
            throw err;
        }
    }
    /**
    * Query auditorium by id
    * @param id
    */
    findSeats(id) {
        return this.seats.find({ auditoriumId: id, booked: false });
    }
    /**
   * Query for seat available
   * @param id
   */
    checkSeatAvailable(auditoriumId, seatId) {
        return this.seats.findOne({ auditoriumId: auditoriumId, id: seatId, booked: false });
    }
    /**
     * Update  by id
     * @param id
     * @param data
     */
    updateSeat(_id, bookingId) {
        return this.seats.findOneAndUpdate({ _id }, { bookingId, booked: true });
    }
}
exports.SeatsService = SeatsService;
//# sourceMappingURL=seats.service.js.map