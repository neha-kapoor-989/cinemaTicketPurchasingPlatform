"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateSeatDTO = void 0;
class CreateSeatDTO {
}
exports.CreateSeatDTO = CreateSeatDTO;
//# sourceMappingURL=seats.schema.js.map