"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserService = void 0;
class UserService {
    constructor(user) {
        this.user = user;
    }
    /**
     * Create users
     * @param params
     */
    async createUser(params) {
        try {
            const result = await this.user.create({
                name: params.name,
                email: params.email,
                phoneNumber: params.phoneNumber,
            });
            return result;
        }
        catch (err) {
            console.error('createAuditorium', err);
            throw err;
        }
    }
    /**
     * Query user with email
     * @param id
     */
    findUserByEmail(email) {
        return this.user.findOne({ email: email });
    }
}
exports.UserService = UserService;
//# sourceMappingURL=user.service.js.map