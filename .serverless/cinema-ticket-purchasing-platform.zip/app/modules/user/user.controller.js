"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserController = void 0;
const user_service_1 = require("./user.service");
class UserController extends user_service_1.UserService {
    constructor(auditoriums) {
        super(auditoriums);
    }
    /**
     * Create user
     * @param {*} event
     */
    async create(params) {
        try {
            const result = await this.createUser({
                name: params.name,
                email: params.email,
                phoneNumber: params.phoneNumber,
            });
            return { id: result?._id };
        }
        catch (err) {
            return { id: null };
        }
    }
}
exports.UserController = UserController;
//# sourceMappingURL=user.controller.js.map