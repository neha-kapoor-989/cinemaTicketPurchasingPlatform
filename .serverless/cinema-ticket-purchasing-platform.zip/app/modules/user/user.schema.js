"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateUserDTO = void 0;
class CreateUserDTO {
}
exports.CreateUserDTO = CreateUserDTO;
//# sourceMappingURL=user.schema.js.map