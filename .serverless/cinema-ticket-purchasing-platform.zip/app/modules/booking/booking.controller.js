"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BookingController = void 0;
const booking_service_1 = require("./booking.service");
class BookingController extends booking_service_1.BookingService {
    constructor(bookings) {
        super(bookings);
    }
    /**
     * Create bookings
     * @param {*} event
     */
    async createBooking(params) {
        try {
            const result = await this.create(params);
            return result?._id;
        }
        catch (err) {
            return null;
        }
    }
}
exports.BookingController = BookingController;
//# sourceMappingURL=booking.controller.js.map