"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BookingService = void 0;
class BookingService {
    constructor(bookings) {
        this.bookings = bookings;
    }
    /**
     * Create cooking
     * @param params
     */
    async create(userId) {
        try {
            console.log('userId', userId);
            const result = await this.bookings.create({
                userId,
                reserved: true,
                paid: true,
            });
            console.log('createBooking', result);
            return result;
        }
        catch (err) {
            console.log('createBooking', err);
            throw err;
        }
    }
}
exports.BookingService = BookingService;
//# sourceMappingURL=booking.service.js.map