"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuditoriumService = void 0;
class AuditoriumService {
    constructor(auditorium) {
        this.auditorium = auditorium;
    }
    /**
     * Create auditorium
     * @param params
     */
    async createAuditorium(params) {
        try {
            const result = await this.auditorium.create({
                name: params.name,
                id: params.id,
                totalSeats: params.totalSeats,
                description: params?.description,
            });
            return result;
        }
        catch (err) {
            console.error('createAuditorium', err);
            throw err;
        }
    }
    /**
     * Find auditorium
     */
    findAuditoriums() {
        return this.auditorium.find();
    }
    /**
     * Query auditorium by id
     * @param id
     */
    findOneAuditoriumById(id) {
        return this.auditorium.findOne({ id });
    }
    /**
     * Delete auditorium by id
     * @param id
     */
    deleteOneAuditoriumById(id) {
        return this.auditorium.deleteOne({ id });
    }
}
exports.AuditoriumService = AuditoriumService;
//# sourceMappingURL=auditorium.service.js.map