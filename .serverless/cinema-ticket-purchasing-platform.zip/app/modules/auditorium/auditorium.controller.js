"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuditoriumController = void 0;
const message_1 = require("../../utils/message");
const auditorium_service_1 = require("./auditorium.service");
const user_controller_1 = require("../user/user.controller");
const seats_controller_1 = require("../seats/seats.controller");
const booking_controller_1 = require("../booking/booking.controller");
const model_1 = require("../../model");
const seatsController = new seats_controller_1.SeatsController(model_1.seats);
const userController = new user_controller_1.UserController(model_1.users);
const bookingController = new booking_controller_1.BookingController(model_1.bookings);
class AuditoriumController extends auditorium_service_1.AuditoriumService {
    constructor(auditoriums) {
        super(auditoriums);
    }
    /**
     * Create auditorium
     * @param {*} event
     */
    async create(event, context) {
        console.log('functionName', context.functionName);
        const params = JSON.parse(event.body);
        try {
            const result = await this.createAuditorium({
                name: params.name,
                id: params.id,
                totalSeats: params.totalSeats,
                description: params?.description,
            });
            console.log(result._id);
            await seatsController.createAuditoriumSeats(result._id, params.id, params.totalSeats);
            return message_1.MessageUtil.success(result);
        }
        catch (err) {
            return message_1.MessageUtil.error(err.code, err.message);
        }
    }
    /**
   * Create a booking
   * @param {*} event
   */
    async createBooking(event, context) {
        const params = JSON.parse(event.body);
        try {
            const result = await seatsController.checkSeatFree(event.pathParameters.id, params.seat);
            if (result) {
                //create booking now
                const userCreated = await userController.create({
                    name: params.name,
                    email: params.email,
                    phoneNumber: params.phoneNumber,
                });
                console.log(userCreated);
                if (userCreated.id) {
                    const booking = await bookingController.createBooking(userCreated.id);
                    await seatsController.update(result._id, booking?._id);
                    return message_1.MessageUtil.success({ message: "Your seat is booked" });
                }
                else {
                    return message_1.MessageUtil.error(422, "User already made a booking");
                }
            }
            else {
                return message_1.MessageUtil.error(422, "This seat is already booked");
            }
        }
        catch (err) {
            return message_1.MessageUtil.error(err.code, err.message);
        }
    }
    /**
     * Find auditorium list
     */
    async find() {
        try {
            const result = await this.findAuditoriums();
            return message_1.MessageUtil.success(result);
        }
        catch (err) {
            console.error(err);
            return message_1.MessageUtil.error(err.code, err.message);
        }
    }
    /**
     * Query auditorium by id
     * @param event
     */
    async findAvailable(event, context) {
        const id = String(event.pathParameters.id);
        try {
            const result = await this.findOneAuditoriumById(id);
            if (result && result._id) {
                const seats = await seatsController.findAvailableSeats(id);
                return message_1.MessageUtil.success(seats);
            }
            else {
                return message_1.MessageUtil.error(404, 'Seat not available');
            }
        }
        catch (err) {
            console.error(err);
            return message_1.MessageUtil.error(err.code, err.message);
        }
    }
    /**
     * Delete auditorium by id
     * @param event
     */
    async deleteOne(event) {
        const id = event.pathParameters.id;
        try {
            const result = await this.deleteOneAuditoriumById(id);
            if (result.deletedCount === 0) {
                return message_1.MessageUtil.error(1010, 'The data was not found! May have been deleted!');
            }
            return message_1.MessageUtil.success(result);
        }
        catch (err) {
            console.error(err);
            return message_1.MessageUtil.error(err.code, err.message);
        }
    }
}
exports.AuditoriumController = AuditoriumController;
//# sourceMappingURL=auditorium.controller.js.map