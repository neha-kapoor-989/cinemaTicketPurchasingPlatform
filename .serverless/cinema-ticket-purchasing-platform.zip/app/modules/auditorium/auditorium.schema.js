"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateCinemaDTO = void 0;
class CreateCinemaDTO {
}
exports.CreateCinemaDTO = CreateCinemaDTO;
//# sourceMappingURL=auditorium.schema.js.map